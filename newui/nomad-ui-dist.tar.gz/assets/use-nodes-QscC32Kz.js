import{u as e,t as o}from"./common-DA4-3bqY.js";function r(s){return e(["nodes","list",JSON.stringify(s)],"/v1/nodes",{params:o(s),throttleMs:5e3})}export{r as u};
//# sourceMappingURL=use-nodes-QscC32Kz.js.map
