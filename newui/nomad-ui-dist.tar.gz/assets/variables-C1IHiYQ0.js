import{g as r}from"./index-DT6X-OQw.js";function u(e){return r().get("/v1/vars",e)}function i(e,a){return r().get(`/v1/var/${e}`,a)}function v(e,a,t){return r().put(`/v1/var/${e}`,a,t)}function o(e,a,t){return r().put(`/v1/var/${e}`,a,t)}function l(e,a){return r().delete(`/v1/var/${e}`,a)}export{i as a,v as c,l as d,u as g,o as u};
//# sourceMappingURL=variables-C1IHiYQ0.js.map
