/**
 * Copyright IBM Corp. 2015, 2026
 * SPDX-License-Identifier: BUSL-1.1
 */

import {
  currentURL,
  click,
  typeIn,
  waitUntil,
  find,
} from '@ember/test-helpers';
import { getPageTitle } from 'ember-page-title/test-support';
import { module, test } from 'qunit';
import { setupApplicationTest } from 'ember-qunit';
import { setupMirage } from 'ember-cli-mirage/test-support';
import a11yAudit from 'nomad-ui/tests/helpers/a11y-audit';
import Versions from 'nomad-ui/tests/pages/jobs/job/versions';
import Layout from 'nomad-ui/tests/pages/layout';
import moment from 'moment';
import faker from 'nomad-ui/mirage/faker';
let job;
let namespace;
let versions;

module('Acceptance | job versions', function (hooks) {
  setupApplicationTest(hooks);
  setupMirage(hooks);

  hooks.beforeEach(async function () {
    faker.seed(1);
    this.server.create('node-pool');
    this.server.create('namespace');
    namespace = this.server.create('namespace');

    job = this.server.create('job', {
      namespaceId: namespace.id,
      createAllocations: false,
      noDeployments: true,
      type: 'service',
    });

    // Create some versions
    this.server.create('job-version', {
      job: job,
      version: 0,
    });
    this.server.create('job-version', {
      job: job,
      version: 1,
      versionTag: {
        Name: 'test-tag',
        Description: 'A tag with a brief description',
      },
    });
    versions = this.server.db.jobVersions.where({ jobId: job.id });

    const managementToken = this.server.create('token');
    window.localStorage.nomadTokenSecret = managementToken.secretId;

    await Versions.visit({ id: `${job.id}@${namespace.id}` });
  });

  test('it passes an accessibility audit', async function (assert) {
    await a11yAudit(assert);
  });

  test('/jobs/:id/versions should list all job versions', async function (assert) {
    assert.deepEqual(
      Versions.versions.length,
      versions.length,
      'Each version gets a row in the timeline',
    );
    assert.deepEqual(getPageTitle(), `Job ${job.name} versions - Nomad`);
  });

  test('each version mentions the version number, the stability, and the submitted time', async function (assert) {
    const version = versions.sortBy('submitTime').reverse()[0];
    const formattedSubmitTime = moment(version.submitTime / 1000000).format(
      "MMM DD, 'YY HH:mm:ss ZZ",
    );
    const versionRow = Versions.versions.objectAt(0);

    assert.ok(
      versionRow.text.includes(`Version #${version.version}`),
      'Version #',
    );
    assert.deepEqual(
      versionRow.stability,
      version.stable.toString(),
      'Stability',
    );
    assert.deepEqual(versionRow.submitTime, formattedSubmitTime, 'Submit time');
  });

  test('all versions but the current one have a button to revert to that version', async function (assert) {
    let versionRowToRevertTo;

    Versions.versions.forEach((versionRow) => {
      if (versionRow.number === job.version) {
        assert.ok(versionRow.revertToButton.isHidden);
      } else {
        assert.ok(versionRow.revertToButton.isPresent);

        versionRowToRevertTo = versionRow;
      }
    });

    if (versionRowToRevertTo) {
      const versionNumberRevertingTo = versionRowToRevertTo.number;
      await versionRowToRevertTo.revertToButton.idle();
      await versionRowToRevertTo.revertToButton.confirm();

      const revertRequest = this.server.pretender.handledRequests.find(
        (request) => request.url.includes('revert'),
      );

      assert.deepEqual(
        revertRequest.url,
        `/v1/job/${job.id}/revert?namespace=${namespace.id}`,
      );

      assert.deepEqual(JSON.parse(revertRequest.requestBody), {
        JobID: job.id,
        JobVersion: versionNumberRevertingTo,
      });

      await waitUntil(() => currentURL() === `/jobs/${job.id}@${namespace.id}`);
      assert.deepEqual(currentURL(), `/jobs/${job.id}@${namespace.id}`);
    }
  });

  test('when reversion fails, the error message from the API is piped through to the alert', async function (assert) {
    const versionRowToRevertTo = Versions.versions.filter(
      (versionRow) => versionRow.revertToButton.isPresent,
    )[0];

    if (versionRowToRevertTo) {
      const message = 'A plaintext error message';
      this.server.pretender.post('/v1/job/:id/revert', () => [
        500,
        {},
        message,
      ]);

      await versionRowToRevertTo.revertToButton.idle();
      await versionRowToRevertTo.revertToButton.confirm();
      await waitUntil(() => Layout.inlineError.isShown);

      assert.ok(Layout.inlineError.isShown);
      assert.ok(Layout.inlineError.isDanger);
      assert.ok(Layout.inlineError.title.includes('Could Not Revert'));
      assert.deepEqual(Layout.inlineError.message, message);

      await Layout.inlineError.dismiss();

      assert.notOk(Layout.inlineError.isShown);
    }
  });

  test('when reversion has no effect, the error message explains', async function (assert) {
    const versionRowToRevertTo = Versions.versions.filter(
      (versionRow) => versionRow.revertToButton.isPresent,
    )[0];

    if (versionRowToRevertTo) {
      // The default Mirage implementation updates the job version as passed in, this does nothing
      this.server.pretender.post('/v1/job/:id/revert', () => [200, {}, '{}']);

      await versionRowToRevertTo.revertToButton.idle();
      await versionRowToRevertTo.revertToButton.confirm();
      await waitUntil(() => Layout.inlineError.isShown);

      assert.ok(Layout.inlineError.isShown);
      assert.ok(Layout.inlineError.isWarning);
      assert.ok(Layout.inlineError.title.includes('Reversion Had No Effect'));
      assert.deepEqual(
        Layout.inlineError.message,
        'Reverting to an identical older version doesn’t produce a new version',
      );
    }
  });

  test('when the job for the versions is not found, an error message is shown, but the URL persists', async function (assert) {
    await Versions.visit({ id: 'not-a-real-job' });

    assert.deepEqual(
      this.server.pretender.handledRequests
        .filter((request) => !request.url.includes('policy'))
        .findBy('status', 404).url,
      '/v1/job/not-a-real-job',
      'A request to the nonexistent job is made',
    );
    assert.deepEqual(
      currentURL(),
      '/jobs/not-a-real-job/versions',
      'The URL persists',
    );
    assert.ok(Versions.error.isPresent, 'Error message is shown');
  });

  test('version tags are displayed', async function (assert) {
    // Both a tagged version and an untagged version are present
    assert.dom('[data-test-tagged-version="true"]').exists();
    assert.dom('[data-test-tagged-version="false"]').exists();

    // The tagged version has a button indicating a tag name and description
    assert
      .dom('[data-test-tagged-version="true"] .tag-button-primary')
      .hasText('test-tag');
    assert
      .dom('[data-test-tagged-version="true"] .tag-description')
      .hasText('A tag with a brief description');

    // The untagged version has no tag button or description
    assert
      .dom('[data-test-tagged-version="false"] .tag-button-primary')
      .doesNotExist();
    assert
      .dom('[data-test-tagged-version="false"] .tag-description')
      .hasText('', 'Tag description is empty');
  });

  test('existing version tags can be edited', async function (assert) {
    // Clicking the tag button puts it into edit mode
    assert
      .dom('[data-test-tagged-version="true"] .boxed-section-foot')
      .doesNotHaveClass('editing');
    await click('[data-test-tagged-version="true"] .tag-button-primary');
    assert
      .dom('[data-test-tagged-version="true"] .boxed-section-foot')
      .hasClass('editing');

    // equivalent of backspacing existing
    find('[data-test-tag-name-input]').value = '';
    find('[data-test-tag-description-input]').value = '';

    await typeIn(
      '[data-test-tagged-version="true"] [data-test-tag-name-input]',
      'new-tag',
    );
    await typeIn(
      '[data-test-tagged-version="true"] [data-test-tag-description-input]',
      'new-description',
    );

    // Clicking the save button commits the changes
    await click(
      '[data-test-tagged-version="true"] [data-test-tag-save-button]',
    );
    assert
      .dom('[data-test-tagged-version="true"] .tag-button-primary')
      .hasText('new-tag');
    assert
      .dom('[data-test-tagged-version="true"] .tag-description')
      .hasText('new-description');

    assert
      .dom('.flash-message.alert.alert-success')
      .exists('Shows a success toast notification on edit.');

    // Tag can subsequently be deleted
    await click('[data-test-tagged-version="true"] .tag-button-primary');
    await click(
      '[data-test-tagged-version="true"] [data-test-tag-delete-button]',
    );
    await waitUntil(() => !find('[data-test-tagged-version="true"]'));
    assert.dom('[data-test-tagged-version="true"]').doesNotExist();
  });

  test('new version tags can be created', async function (assert) {
    // Clicking the tag button puts it into edit mode
    assert
      .dom('[data-test-tagged-version="false"] .boxed-section-foot')
      .doesNotHaveClass('editing');
    await click('[data-test-tagged-version="false"] .tag-button-secondary');
    assert
      .dom('[data-test-tagged-version="false"] .boxed-section-foot')
      .hasClass('editing');

    assert
      .dom('[data-test-tagged-version="false"] [data-test-tag-delete-button]')
      .doesNotExist();

    // Clicking the save button commits the changes
    await click(
      '[data-test-tagged-version="false"] [data-test-tag-save-button]',
    );

    assert
      .dom('.flash-message.alert.alert-critical')
      .exists('Shows an error toast notification without a tag name.');

    await typeIn(
      '[data-test-tagged-version="false"] [data-test-tag-name-input]',
      'new-tag',
    );
    await typeIn(
      '[data-test-tagged-version="false"] [data-test-tag-description-input]',
      'new-description',
    );

    // Clicking the save button commits the changes
    await click(
      '[data-test-tagged-version="false"] [data-test-tag-save-button]',
    );

    assert
      .dom('[data-test-tagged-version="false"]')
      .doesNotExist('Both versions now have tags');

    assert
      .dom('.flash-message.alert.alert-success')
      .exists('Shows a success toast notification on edit.');
  });
});

// Module for Clone and Edit
module('Acceptance | job versions (clone and edit)', function (hooks) {
  setupApplicationTest(hooks);
  setupMirage(hooks);

  hooks.beforeEach(async function () {
    this.server.create('node-pool');
    namespace = this.server.create('namespace');

    const managementToken = this.server.create('token');
    window.localStorage.nomadTokenSecret = managementToken.secretId;

    job = this.server.create('job', {
      createAllocations: false,
      version: 99,
      namespaceId: namespace.id,
    });
    // remove auto-created versions and create 3 of them, one with a tag
    this.server.db.jobVersions.remove();
    this.server.create('job-version', {
      job,
      version: 99,
      submitTime: 1731101785761339000,
    });
    this.server.create('job-version', {
      job,
      version: 98,
      submitTime: 1731101685761339000,
      versionTag: {
        Name: 'test-tag',
        Description: 'A tag with a brief description',
      },
    });
    this.server.create('job-version', {
      job,
      version: 0,
      submitTime: 1731101585761339000,
    });
    await Versions.visit({ id: job.id });
  });

  test('Clone and edit buttons are shown', async function (assert) {
    assert.dom('.job-version').exists({ count: 3 });
    assert
      .dom('[data-test-clone-and-edit]')
      .exists(
        { count: 2 },
        'Current job version doesnt have clone or revert buttons',
      );

    const versionBlock = '[data-test-job-version="98"]';

    assert
      .dom(`${versionBlock} [data-test-clone-as-new-version]`)
      .doesNotExist(
        'Confirmation-stage clone-as-new-version button doesnt exist on initial load',
      );
    assert
      .dom(`${versionBlock} [data-test-clone-as-new-job]`)
      .doesNotExist(
        'Confirmation-stage clone-as-new-job button doesnt exist on initial load',
      );

    await click(`${versionBlock} [data-test-clone-and-edit]`);

    assert
      .dom(`${versionBlock} [data-test-clone-as-new-version]`)
      .exists(
        'Confirmation-stage clone-as-new-version button exists after clicking clone and edit',
      );

    assert
      .dom(`${versionBlock} [data-test-clone-as-new-job]`)
      .exists(
        'Confirmation-stage clone-as-new-job button exists after clicking clone and edit',
      );

    assert
      .dom(`${versionBlock} [data-test-revert-to]`)
      .doesNotExist('Revert button is hidden when Clone buttons are expanded');

    assert
      .dom('[data-test-job-version="0"] [data-test-revert-to]')
      .exists('Revert button is visible for other versions');

    await click(`${versionBlock} [data-test-cancel-clone]`);

    assert
      .dom(`${versionBlock} [data-test-clone-as-new-version]`)
      .doesNotExist(
        'Confirmation-stage clone-as-new-version button doesnt exist after clicking cancel',
      );
  });

  test('Clone as new version', async function (assert) {
    const versionBlock = '[data-test-job-version="98"]';
    await click(`${versionBlock} [data-test-clone-and-edit]`);
    await click(`${versionBlock} [data-test-clone-as-new-version]`);

    assert.deepEqual(
      currentURL(),
      `/jobs/${job.id}@${namespace.id}/definition?isEditing=true&version=98&view=job-spec`,
      'Taken to the definition page in edit mode',
    );
  });

  test('Clone as new version when version is 0', async function (assert) {
    const versionBlock = '[data-test-job-version="0"]';
    await click(`${versionBlock} [data-test-clone-and-edit]`);
    await click(`${versionBlock} [data-test-clone-as-new-version]`);

    assert.deepEqual(
      currentURL(),
      `/jobs/${job.id}@${namespace.id}/definition?isEditing=true&version=0&view=job-spec`,
      'Taken to the definition page in edit mode',
    );
  });

  test('Clone as a new version when no submission info is available', async function (assert) {
    this.server.pretender.get('/v1/job/:id/submission', () => [500, {}, '']);
    const versionBlock = '[data-test-job-version="98"]';
    await click(`${versionBlock} [data-test-clone-and-edit]`);
    await click(`${versionBlock} [data-test-clone-as-new-version]`);

    assert.deepEqual(
      currentURL(),
      `/jobs/${job.id}@${namespace.id}/definition?isEditing=true&version=98&view=full-definition`,
      'Taken to the definition page in edit mode',
    );

    assert.dom('[data-test-json-warning]').exists();
  });

  test('Clone as a new job', async function (assert) {
    const testString =
      'Test string that should appear in my sourceString url param';
    this.server.pretender.get('/v1/job/:id/submission', () => [
      200,
      {},
      JSON.stringify({
        Source: testString,
      }),
    ]);
    const versionBlock = '[data-test-job-version="98"]';
    await click(`${versionBlock} [data-test-clone-and-edit]`);
    await click(`${versionBlock} [data-test-clone-as-new-job]`);
    await waitUntil(
      () =>
        currentURL() ===
        `/jobs/run?sourceString=${encodeURIComponent(testString)}`,
    );

    assert.deepEqual(
      currentURL(),
      `/jobs/run?sourceString=${encodeURIComponent(testString)}`,
      'Taken to the new job page',
    );
    assert.dom('[data-test-job-name-warning]').exists();
  });
});

module('Acceptance | job versions (with client token)', function (hooks) {
  setupApplicationTest(hooks);
  setupMirage(hooks);
  let namespace2;
  let namespace3;
  let job2;
  let job3;

  hooks.beforeEach(async function () {
    this.server.create('node-pool');
    this.server.create('namespace');
    this.server.create('token');
    namespace = this.server.create('namespace');

    job = this.server.create('job', {
      namespaceId: namespace.id,
      createAllocations: false,
      noDeployments: true,
      type: 'service',
    });

    // Create some versions
    this.server.create('job-version', {
      job: job,
      version: 0,
    });
    this.server.create('job-version', {
      job: job,
      version: 1,
      versionTag: {
        Name: 'test-tag',
        Description: 'A tag with a brief description',
      },
    });

    namespace2 = this.server.create('namespace');
    job2 = this.server.create('job', {
      namespaceId: namespace2.id,
      createAllocations: false,
      noDeployments: true,
      type: 'service',
    });

    // Create job2 versions
    this.server.create('job-version', {
      job: job2,
      version: 0,
    });
    this.server.create('job-version', {
      job: job2,
      version: 1,
      versionTag: {
        Name: 'test-tag',
        Description: 'A tag with a brief description',
      },
    });

    namespace3 = this.server.create('namespace');
    job3 = this.server.create('job', {
      namespaceId: namespace3.id,
      createAllocations: false,
      noDeployments: true,
      type: 'service',
    });

    // Create job3 versions
    this.server.create('job-version', {
      job: job3,
      version: 0,
    });
    this.server.create('job-version', {
      job: job3,
      version: 1,
      versionTag: {
        Name: 'test-tag',
        Description: 'A tag with a brief description',
      },
    });
  });

  test('Revert buttons are disabled when the token lacks permissions', async function (assert) {
    window.localStorage.clear();

    const clientToken = this.server.create('token');

    const policy = this.server.create('policy', {
      id: 'revert-policy',
      name: 'revert-policy',
      rulesJSON: {
        Namespaces: [
          {
            Name: namespace.id,
            Capabilities: ['submit-job'],
          },
          {
            Name: namespace2.id,
            Capabilities: ['revert-job'],
          },
          {
            Name: namespace2.id,
            Capabilities: ['read-job'],
          },
        ],
      },
    });

    clientToken.policyIds = [policy.id];
    clientToken.save();

    window.localStorage.nomadTokenSecret = clientToken.secretId;

    await Versions.visit({ id: `${job.id}@${namespace.id}` });
    Versions.versions.forEach((versionRow) => {
      if (versionRow.number === job.version) {
        assert.ok(versionRow.revertToButton.isHidden);
      } else {
        assert.ok(versionRow.revertToButton.isPresent);
        assert.notOk(versionRow.revertToButton.isDisabled);
      }
    });

    await Versions.visit({ id: `${job2.id}@${namespace2.id}` });
    Versions.versions.forEach((versionRow) => {
      if (versionRow.number === job.version) {
        assert.ok(versionRow.revertToButton.isHidden);
      } else {
        assert.ok(versionRow.revertToButton.isPresent);
        assert.notOk(versionRow.revertToButton.isDisabled);
      }
    });

    await Versions.visit({ id: `${job3.id}@${namespace3.id}` });
    Versions.versions.forEach((versionRow) => {
      if (versionRow.number === job.version) {
        assert.ok(versionRow.revertToButton.isHidden);
      } else {
        assert.ok(versionRow.revertToButton.isPresent);
        assert.ok(versionRow.revertToButton.isDisabled);
      }
    });
  });

  test('Clone buttons are removed when the token lacks job-register permissions', async function (assert) {
    window.localStorage.clear();

    const clientToken = this.server.create('token');

    const policy = this.server.create('policy', {
      id: 'clone-policy',
      name: 'clone-policy',
      rulesJSON: {
        Namespaces: [
          {
            Name: '*',
            Capabilities: ['read-job'],
          },
        ],
      },
    });

    clientToken.policyIds = [policy.id];
    clientToken.save();

    window.localStorage.nomadTokenSecret = clientToken.secretId;

    await Versions.visit({ id: `${job.id}@${namespace.id}` });
    assert
      .dom('[data-test-clone-and-edit]')
      .doesNotExist(
        'Current job version should not have clone or revert buttons',
      );
  });

  test('Clone/Edit buttons are removed depending on client token permissions', async function (assert) {
    window.localStorage.clear();

    const clientToken = this.server.create('token');
    const policy = this.server.create('policy', {
      id: 'clone-policy',
      name: 'clone-policy',
      rulesJSON: {
        Namespaces: [
          {
            Name: namespace.id,
            Capabilities: ['submit-job'],
          },
          {
            Name: namespace2.id,
            Capabilities: ['register-job'],
          },
          {
            Name: namespace2.id,
            Capabilities: ['read-job'],
          },
        ],
      },
    });

    clientToken.policyIds = [policy.id];
    clientToken.save();

    window.localStorage.nomadTokenSecret = clientToken.secretId;

    await Versions.visit({ id: `${job.id}@${namespace.id}` });
    assert
      .dom('[data-test-clone-and-edit]')
      .exists('Current job version should have clone or revert buttons');

    await click(`[data-test-clone-and-edit]`);

    assert
      .dom(`[data-test-clone-as-new-version]`)
      .exists(
        'Confirmation-stage clone-as-new-version button exists after clicking clone and edit',
      );

    assert
      .dom(`[data-test-clone-as-new-job]`)
      .exists(
        'Confirmation-stage clone-as-new-job button exists after clicking clone and edit',
      );

    await Versions.visit({ id: `${job2.id}@${namespace2.id}` });
    assert
      .dom('[data-test-clone-and-edit]')
      .exists('Current job version should have clone or revert buttons');

    await click(`[data-test-clone-and-edit]`);

    assert
      .dom(`[data-test-clone-as-new-version]`)
      .exists(
        'Confirmation-stage clone-as-new-version button exists after clicking clone and edit',
      );

    assert
      .dom(`[data-test-clone-as-new-job]`)
      .exists(
        'Confirmation-stage clone-as-new-job button exists after clicking clone and edit',
      );

    await Versions.visit({ id: `${job3.id}@${namespace3.id}` });
    assert
      .dom('[data-test-clone-and-edit]')
      .exists('Current job version does have clone or revert buttons');

    await click(`[data-test-clone-and-edit]`);

    assert
      .dom(`[data-test-clone-as-new-version]`)
      .doesNotExist(
        'Confirmation-stage clone-as-new-version button does not exist after clicking clone and edit',
      );

    assert
      .dom(`[data-test-clone-as-new-job]`)
      .exists(
        'Confirmation-stage clone-as-new-job button exists after clicking clone and edit',
      );
  });

  test('Tag Version buttons are removed depending on client token permissions', async function (assert) {
    window.localStorage.clear();

    const clientToken = this.server.create('token');
    const policy = this.server.create('policy', {
      id: 'clone-policy',
      name: 'clone-policy',
      rulesJSON: {
        Namespaces: [
          {
            Name: namespace.id,
            Capabilities: ['submit-job'],
          },
          {
            Name: namespace2.id,
            Capabilities: ['tag-job-version'],
          },
          {
            Name: namespace2.id,
            Capabilities: ['read-job'],
          },
        ],
      },
    });

    clientToken.policyIds = [policy.id];
    clientToken.save();

    window.localStorage.nomadTokenSecret = clientToken.secretId;

    await Versions.visit({ id: `${job.id}@${namespace.id}` });
    assert.dom('[data-test-tagged-version="true"]').exists();
    assert.dom('[data-test-tagged-version="false"]').exists();

    assert
      .dom('[data-test-tagged-version="true"] .tag-button-primary')
      .hasText('test-tag');
    assert
      .dom('[data-test-tagged-version="true"] .tag-description')
      .hasText('A tag with a brief description');

    assert
      .dom('[data-test-tagged-version="false"] [data-test-version-tag]')
      .exists();

    await Versions.visit({ id: `${job2.id}@${namespace2.id}` });
    assert.dom('[data-test-tagged-version="true"]').exists();
    assert.dom('[data-test-tagged-version="false"]').exists();

    assert
      .dom('[data-test-tagged-version="true"] .tag-button-primary')
      .hasText('test-tag');
    assert
      .dom('[data-test-tagged-version="true"] .tag-description')
      .hasText('A tag with a brief description');

    assert
      .dom('[data-test-tagged-version="false"] [data-test-version-tag]')
      .exists();

    await Versions.visit({ id: `${job3.id}@${namespace3.id}` });
    assert.dom('[data-test-tagged-version="true"]').exists();
    assert.dom('[data-test-tagged-version="false"]').exists();

    assert
      .dom('[data-test-tagged-version="true"] .tag-button-primary')
      .hasText('test-tag');
    assert
      .dom('[data-test-tagged-version="true"] .tag-description')
      .hasText('A tag with a brief description');

    assert
      .dom('[data-test-tagged-version="false"] [data-test-version-tag]')
      .doesNotExist();
  });
});
