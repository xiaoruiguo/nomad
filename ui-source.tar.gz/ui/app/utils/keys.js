/**
 * Copyright IBM Corp. 2015, 2026
 * SPDX-License-Identifier: BUSL-1.1
 */

export default {
  LEFT_ARROW: '\x1b[D',
  UP_ARROW: '\x1b[A',
  RIGHT_ARROW: '\x1b[C',
  DOWN_ARROW: '\x1b[B',
  CONTROL_A: '\x01',
  CONTROL_U: '\x15',
  ENTER: '\r',
  DELETE: '\x7F',
};
