/**
 * Copyright IBM Corp. 2015, 2026
 * SPDX-License-Identifier: BUSL-1.1
 */

import { Model, hasMany, belongsTo } from 'miragejs';

export default Model.extend({
  taskGroups: hasMany('task-group'),
  jobSummary: belongsTo('job-summary'),
  jobScale: belongsTo('job-scale'),
});
